from flask import Flask, render_template, request, jsonify, send_file
from pathlib import Path
from urllib.parse import urlparse, unquote
import json, threading, uuid, re, os, requests, time

BASE = Path(__file__).resolve().parent
CATALOG_FILE = BASE / 'catalog.json'
DOWNLOAD_DIR = BASE / 'downloads'
DOWNLOAD_DIR.mkdir(exist_ok=True)
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024
jobs = {}
lock = threading.Lock()

def load_catalog():
    return json.loads(CATALOG_FILE.read_text(encoding='utf-8'))
def save_catalog(data):
    CATALOG_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
def safe_name(s):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(s)).strip(' .')[:160] or 'video'
def valid_url(s):
    try:
        p = urlparse((s or '').strip())
        return p.scheme in ('http','https') and bool(p.netloc) and not p.username and not p.password
    except Exception: return False

@app.get('/')
def index(): return render_template('index.html')
@app.get('/api/catalog')
def catalog(): return jsonify(load_catalog())
@app.post('/api/source')
def update_source():
    body = request.get_json(force=True)
    sid, eid, url = body.get('seriesId'), str(body.get('episode')), (body.get('url') or '').strip()
    if not valid_url(url): return jsonify(error='Enter a valid http:// or https:// URL.'), 400
    data = load_catalog(); found = False
    for s in data['series']:
        if s['id'] == sid:
            for ep in s['episodes']:
                if str(ep['number']) == eid:
                    ep['url'] = url; found = True; break
    if not found: return jsonify(error='Episode not found.'), 404
    save_catalog(data)
    return jsonify(ok=True)

@app.get('/api/jobs')
def get_jobs():
    with lock: return jsonify(list(jobs.values()))

def worker(jid, item):
    try:
        with lock: jobs[jid].update(status='downloading', progress=0, message='Connecting…')
        with requests.get(item['url'], stream=True, timeout=(20, 60), headers={'User-Agent':'AnimeLibrary/1.0'}) as r:
            r.raise_for_status()
            total = int(r.headers.get('content-length') or 0)
            path = DOWNLOAD_DIR / (safe_name(item['title']) + '.mp4')
            done = 0
            with open(path, 'wb') as f:
                for chunk in r.iter_content(1024*512):
                    if not chunk: continue
                    f.write(chunk); done += len(chunk)
                    with lock:
                        jobs[jid].update(progress=round(done*100/total,1) if total else None,
                                         message=f'{done/1048576:.1f} MB' + (f' / {total/1048576:.1f} MB' if total else ''))
        with lock: jobs[jid].update(status='complete', progress=100, message='Saved', filename=path.name)
    except Exception as e:
        with lock: jobs[jid].update(status='error', message=str(e)[:240])

@app.post('/api/download')
def download():
    body = request.get_json(force=True); items = body.get('items') or []
    data = load_catalog(); lookup = {}
    for s in data['series']:
        for ep in s['episodes']:
            lookup[(s['id'], str(ep['number']))] = {'url':ep.get('url',''), 'title':f"{s['title']} - {ep['label']}"}
    accepted=[]
    for it in items:
        src=lookup.get((it.get('seriesId'), str(it.get('episode'))))
        if src and valid_url(src['url']): accepted.append(src)
    if not accepted: return jsonify(error='None of the selected episodes has a valid source URL.'), 400
    ids=[]
    for item in accepted:
        jid=uuid.uuid4().hex[:10]
        with lock: jobs[jid]={'id':jid,'title':item['title'],'status':'queued','progress':0,'message':'Waiting'}
        threading.Thread(target=worker,args=(jid,item),daemon=True).start(); ids.append(jid)
    return jsonify(ids=ids, count=len(ids))

@app.get('/downloads/<path:name>')
def serve_download(name): return send_file(DOWNLOAD_DIR / safe_name(name), as_attachment=True)
@app.get('/api/downloaded')
def downloaded():
    return jsonify([{'name':p.name,'size':p.stat().st_size} for p in DOWNLOAD_DIR.iterdir() if p.is_file() and p.name != '.gitkeep'])

if __name__ == '__main__':
    print('Anime Library running at http://127.0.0.1:5000')
    app.run(host='127.0.0.1', port=5000, debug=False, threaded=True)
