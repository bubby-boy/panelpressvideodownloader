# PanelPress Anime Library

A local Flask web app for organizing MP4 anime links, streaming direct MP4 sources in the browser, and downloading episodes into a queue with progress/error status.

## Start on Windows
1. Install Python 3.10 or newer from https://www.python.org/downloads/ (enable **Add Python to PATH**).
2. Double-click `run.bat`.
3. Open http://127.0.0.1:5000 in your browser.

If Windows blocks the batch file, open Command Prompt in this folder and run:

```bat
py -m pip install -r requirements.txt
py app.py
```

## Sources
The catalog includes the six series and season/episode ranges identified from the conversation. Direct URLs that were retained reliably are embedded for Solo Leveling Seasons 1 and 2. Other episodes are listed but marked **Source needed** rather than populated with guessed links. Use **Add URL** on an episode to enter a direct MP4 URL; it is saved to `catalog.json` for next time.

The app requires internet access for streaming/downloading. Some archive hosts may prevent browser playback or direct downloads; use the source's direct MP4 URL when available. Use only media you have permission to access.

## Download behavior
Downloads are saved under `downloads/`. Keep the app running until queued downloads finish. The app is intended for personal/local use; it binds to `127.0.0.1`, not the public network.
